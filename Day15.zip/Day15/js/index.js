let btn=document.getElementById('btn');

let background=document.getElementsByClassName('box1')
btn.addEventListener('click',()=>{
    background.style.backgroundColor="black"
})