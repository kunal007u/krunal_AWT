$(document).ready(()=>{
    $('#mydiv').resizeable();
})